#!/bin/sh 
## Script to initialize a server connection if not present
shost=localhost
sport=8080
smode=$1
sps=$2
if [[ -z "$smode" ]]; then
	echo "need a mode in input"
fi

crestsrvwar=./crestdb-web-1.0-SNAPSHOT.war
function startsrv {
	mode=$1
	authent=$2
	if [[ $mode == "default" ]]; then
		$sport=8090
	fi
	java -Dspring.profiles.active=$mode $authent -jar $crestsrvwar > .crestlog 2>&1 &
}

spid=
crestps=""
if [[ $smode == "default" ]]; then
	$sport=8090
else
	crestps="-Dcrest.db.password=$sps"
fi

sstatus=`curl -s --head http://${shost}:${sport}/crestapi | head -n 1`
if [[ -z "${sstatus// }" ]]; then
	echo "Server is down...starting up in mode $smode and auth $crestps"
	startsrv $smode $crestps & echo $! > run.pid
	cat run.pid
else
	echo "Server is up...kill it"
	spid=`cat run.pid`
	echo "Killing process....$spid"
	kill $spid
fi