# TagDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**time_type** | **str** |  | [optional] 
**object_type** | **str** |  | [optional] 
**synchronization** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**last_validated_time** | **float** |  | [optional] 
**end_of_validity** | **float** |  | [optional] 
**insertion_time** | **datetime** |  | [optional] 
**modification_time** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


