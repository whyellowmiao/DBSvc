# IovDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tag_name** | **str** |  | [optional] 
**since** | **float** |  | [optional] 
**insertion_time** | **datetime** |  | [optional] 
**payload_hash** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


