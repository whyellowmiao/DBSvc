# PayloadDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hash** | **str** |  | [optional] 
**version** | **str** |  | [optional] 
**object_type** | **str** |  | [optional] 
**data** | **str** |  | [optional] 
**streamer_info** | **str** |  | [optional] 
**insertion_time** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


