# GlobalTagMapDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**global_tag_name** | **str** |  | [optional] 
**record** | **str** |  | [optional] 
**label** | **str** |  | [optional] 
**tag_name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


